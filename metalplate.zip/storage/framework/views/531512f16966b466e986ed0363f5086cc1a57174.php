<div class="input-group">
    <input wire:model="search" name="search" type="text" list="mylist" class="form-control" placeholder="Search for..." />
    <span class="input-group-btn"><button class="btn btn-secondary" type="submit">Go!</button></span>
    <?php if(!empty($query)): ?>
        <datalist id="mylist">
            <?php $__currentLoopData = $contentlist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($rs->title); ?>">
                    <?php if($rs->menu_id != '0'): ?>
                    <?php echo e($rs->menu->title); ?>

                    <?php else: ?>
                       Home Page
                    <?php endif; ?>
                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </datalist>
    <?php endif; ?>
</div>
<?php /**PATH D:\MetalPlate\Project\metalplate\resources\views/livewire/search.blade.php ENDPATH**/ ?>