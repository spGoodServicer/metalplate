<?php $__env->startSection('title', 'Contents'); ?>

<?php $__env->startSection('content'); ?>
    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <!-- DATA TABLE -->
                        <h3 class="title-5 m-b-35">Contents</h3>
                        <div class="table-data__tool">
                            <div class="table-data__tool-left">
                                <button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                    <i class="zmdi zmdi-plus"></i><a style="color:white;" href="<?php echo e(route('admin_content_add')); ?>">Add Content</a></button>
                            </div>
                        </div>
                        <div class="table-responsive table-responsive-data2">
                            <table class="table table-data2">
                                <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Menu</th>
                                    <th>Title</th>
                                    <th>Type</th>
                                    <th>Image</th>
                                    <th>Image Gallery</th>
                                    <th>Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $contentlist->sortBy('id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="tr-shadow">
                                        <td><?php echo e($rs->id); ?></td>
                                        <td>
                                            <?php if($rs->menu_id != '0' && $rs->menu): ?>
                                            <?php echo e(\App\Http\Controllers\Admin\MenuController::getParentsTree($rs->menu, $rs->menu->title)); ?>

                                            <?php else: ?>
                                                Home Page
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if($rs->title): ?>
                                                <?php echo e($rs->title); ?>

                                            <?php endif; ?>                                        </td>
                                        <td><?php echo e($rs->type); ?></td>
                                        <td>
                                            <?php if($rs->image): ?>
                                                <img src="<?php echo e(Storage::url($rs->image)); ?>" height="30" alt="" >
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <a style="opacity: 50%;" href="<?php echo e(route('admin_image_add', ['content_id' => $rs->id])); ?>" onclick="return !window.open(this.href, '', 'top=120 left=120 width=640 height=720')"><img height="25" src="<?php echo e(asset('assets/admin/images/')); ?>/images-icon.svg"></a>
                                        </td>
                                        <td>
                                            <span class="status--process"><?php echo e($rs->status); ?></span>
                                        </td>
                                        <td>
                                            <div class="table-data-feature">
                                                <a href="<?php echo e(route('admin_content_edit', ['id'=>$rs->id])); ?>">
                                                    <button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                                        <i class="zmdi zmdi-edit"></i>
                                                    </button>
                                                </a>
                                                <span style="margin-right: 20px;"></span>
                                                <a href="<?php echo e(route('admin_content_delete', ['id'=>$rs->id])); ?>" onclick="return confirm('You are deleting this content! Are you sure?')">
                                                    <button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                                        <i class="zmdi zmdi-delete"></i>
                                                    </button>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr class="spacer"></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- END DATA TABLE -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="copyright">
                            <p>© 2022 moon.rider.dev</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
    <!-- END PAGE CONTAINER-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MetalPlate\Project\metalplate\resources\views/admin/content.blade.php ENDPATH**/ ?>