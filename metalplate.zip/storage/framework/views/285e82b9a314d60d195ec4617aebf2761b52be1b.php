<!-- MENU SIDEBAR-->
<aside class="menu-sidebar d-none d-lg-block">
    <div class="logo">
        <a style="color: cornflowerblue; font-size: 15pt;" href="<?php echo e(route('admin_home')); ?>"><i style="margin-right: 10px;" class="fas fa-shield-alt"></i> Admin Panel </a>
    </div>
    <div class="menu-sidebar__content js-scrollbar1">
        <nav class="navbar-sidebar">
            <ul class="list-unstyled navbar__list">
            <?php echo $__env->make('admin.adminmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </ul>
        </nav>
    </div>
</aside>
<!-- END MENU SIDEBAR-->
<?php /**PATH D:\MetalPlate\Project\metalplate\resources\views/admin/_sidebar.blade.php ENDPATH**/ ?>