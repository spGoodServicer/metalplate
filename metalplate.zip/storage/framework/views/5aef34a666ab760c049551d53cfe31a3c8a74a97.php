<?php $__env->startSection('title', 'Comments'); ?>

<?php $__env->startSection('content'); ?>
    <!-- MAIN CONTENT-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12">
                        <!-- DATA TABLE -->
                        <h3 class="title-5 m-b-35">Comments</h3>
                        <div class="table-responsive table-responsive-data2">
                            <table class="table table-data2">
                                <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Content</th>
                                    <th>User</th>
                                    <th>IP</th>
                                    <th>Comment</th>
                                    <th>Date</th>
                                    <th>Status</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $commentlist->sortBy('id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr class="tr-shadow">
                                        <td><?php echo e($rs->id); ?></td>
                                        <td><a style="color: cornflowerblue;" href="<?php echo e(route('content', ['id' => $rs->content->id, 'slug'=>$rs->content->slug])); ?>"><?php echo e($rs->content->title); ?></a></td>
                                        <td>
                                            <a style="color: cornflowerblue;" href="<?php echo e(route('admin_user_show', ['id' => $rs->user->id])); ?>" onclick="return !window.open(this.href, '', 'top=120 left=120 width=640 height=720')">
                                                <?php echo e($rs->user->name); ?>

                                            </a>
                                        </td>
                                        <td><?php echo e($rs->IP); ?></td>
                                        <td><?php echo e($rs->comment); ?></td>
                                        <td><?php echo e($rs->created_at); ?></td>
                                        <td>
                                            <span class="status--process"><?php echo e($rs->status); ?></span>
                                        </td>
                                        <td>
                                            <div class="table-data-feature">
                                                <a href="<?php echo e(route('admin_comment_show', ['id'=>$rs->id])); ?>"  onclick="return !window.open(this.href, '', 'top=120 left=120 width=640 height=720')">
                                                    <button class="item" data-toggle="tooltip" data-placement="top" title="Edit">
                                                        <i class="zmdi zmdi-edit"></i>
                                                    </button>
                                                </a>
                                                <span style="margin-right: 20px;"></span>
                                                <a href="<?php echo e(route('admin_comment_delete', ['id'=>$rs->id])); ?>" onclick="return confirm('You are deleting this comment! Are you sure?')">
                                                    <button class="item" data-toggle="tooltip" data-placement="top" title="Delete">
                                                        <i class="zmdi zmdi-delete"></i>
                                                    </button>
                                                </a>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr class="spacer"></tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                        <!-- END DATA TABLE -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="copyright">
                            <p>© 2020 Berke Kiran</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN CONTENT-->
    <!-- END PAGE CONTAINER-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MetalPlate\Project\metalplate\resources\views/admin/comment.blade.php ENDPATH**/ ?>