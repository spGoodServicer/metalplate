<?php if($message = Session::get('success')): ?>
    <strong style="color: mediumseagreen;"><?php echo e($message); ?></strong>
<?php endif; ?>
<?php if($message = Session::get('fail')): ?>
    <strong style="color: red;"><?php echo e($message); ?></strong>
<?php endif; ?>
<?php /**PATH D:\MetalPlate\Project\metalplate\resources\views/home/message.blade.php ENDPATH**/ ?>