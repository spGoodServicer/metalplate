<?php $__env->startSection('title', 'FAQ'); ?>
<?php $__env->startSection('description', $setting->description); ?>
<?php $__env->startSection('keywords', $setting->keywords); ?>

<?php $__env->startSection('content'); ?>

    <!-- full Title -->
    <div class="full-title">
        <div class="container">
            <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3"> FAQ </h1>
            <div class="breadcrumb-main">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('home')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item"> FAQ </a>
                    </li>
                </ol>
            </div>
        </div>
    </div>
    <div class="container">
        <h1 style="text-align: center;" class="py-4">Frequently Asked Questions</h1>
    </div>
    <div class="faq-main">
        <div class="container">
            <div class="accordion" id="accordionExample">

            <div class="card accordion-single">
                <div class="card-header" id="1">
                    <h5 class="mb-0">
                        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse<?php echo e($faqlist->first()->position); ?>" aria-expanded="true" aria-controls="collapse<?php echo e($faqlist->first()->position); ?>">
                            <?php echo e($faqlist->first()->question); ?>

                        </button>
                    </h5>
                </div>
                <div id="collapse<?php echo e($faqlist->first()->position); ?>" class="collapse show" data-parent="#accordionExample">
                    <div class="card-body">
                        <?php echo $faqlist->first()->answer; ?>

                    </div>
                </div>
            </div>

            <?php $__currentLoopData = $faqlist->skip(1); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="card accordion-single">
                    <div class="card-header" id="1">
                        <h5 class="mb-0">
                            <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapse<?php echo e($rs->position); ?>" aria-expanded="false" aria-controls="collapse<?php echo e($rs->position); ?>">
                                <?php echo e($rs->question); ?>

                            </button>
                        </h5>
                    </div>
                    <div id="collapse<?php echo e($rs->position); ?>" class="collapse" data-parent="#accordionExample">
                        <div class="card-body">
                            <?php echo $rs->answer; ?>

                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MetalPlate\Project\metalplate\resources\views/home/faq.blade.php ENDPATH**/ ?>