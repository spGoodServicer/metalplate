<?php $__env->startSection('title', $menu->title); ?>
<?php $__env->startSection('description', $menu->description); ?>
<?php $__env->startSection('keywords', $menu->keywords); ?>

<?php $__env->startSection('content'); ?>

    <!-- full Title -->
    <div class="full-title" style="background: url(<?php echo e(Storage::url($menu->image)); ?>) no-repeat center; -webkit-background-size: cover; -moz-background-size: cover; -o-background-size: cover; background-size: cover;">
        <div class="container">
            <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3"> <?php echo e($menu->title); ?> </h1>
            <div class="breadcrumb-main">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <?php if(\App\Models\Menu::where('id','=',$menu->parent_id)->first() != null): ?>
                            <span style="color: white;"><?php echo e(\App\Models\Menu::where('id','=',$menu->parent_id)->first()->title); ?></span>
                        <?php else: ?>
                            <a href="<?php echo e(route('home')); ?> ">Home</a>
                        <?php endif; ?>
                    </li>
                    <li class="breadcrumb-item active"><?php echo e($menu->title); ?></li>
                </ol>
            </div>
        </div>
    </div>

    <div class="blog-main">
        <div class="container">
            <div class="row">

                <!-- Blog Entries Column -->
                <div class="col-md-8 blog-entries">

                    <?php $__currentLoopData = $menucontent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <!-- Blog Post -->
                    <div class="card mb-4">
                        <img class="card-img-top" src="<?php echo e(Storage::url($rs->image)); ?>" alt="Card image Blog" />
                        <div class="card-body">
                            <div class="by-post">
                                Posted on <?php echo e($rs->created_at->format('Y-m-d')); ?> by <span style="color: dodgerblue;"><?php echo e($rs->user->name); ?></span>
                            </div>
                            <h2 class="card-title"><?php echo e($rs->title); ?></h2>
                            <p class="card-text"><?php echo e($rs->description); ?></p>
                            <a href="<?php echo e(route('content', ['id'=>$rs->id, 'slug'=>$rs->slug])); ?>" class="btn btn-primary">Continue &rarr;</a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>

                <!-- Sidebar Widgets Column -->
                <div class="col-md-4 blog-right-side">

                    <div class="card mb-4">
                        <h5 class="card-header">Search</h5>
                        <div class="card-body">
                            <div class="input-group">
                                <form action="<?php echo e(route('getcontent')); ?>" method="post">
                                    <?php echo csrf_field(); ?>
                                    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('search')->html();
} elseif ($_instance->childHasBeenRendered('lltsz8O')) {
    $componentId = $_instance->getRenderedChildComponentId('lltsz8O');
    $componentTag = $_instance->getRenderedChildComponentTagName('lltsz8O');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('lltsz8O');
} else {
    $response = \Livewire\Livewire::mount('search');
    $html = $response->html();
    $_instance->logRenderedChild('lltsz8O', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
                                </form>
                                <?php echo \Livewire\Livewire::scripts(); ?>

                            </div>
                        </div>
                    </div>

                </div>

            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MetalPlate\Project\metalplate\resources\views/home/menu_content.blade.php ENDPATH**/ ?>