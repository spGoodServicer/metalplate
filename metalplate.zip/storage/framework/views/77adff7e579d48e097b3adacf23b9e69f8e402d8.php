<?php $__env->startSection('title', $setting->title); ?>
<?php $__env->startSection('description', $setting->description); ?>
<?php $__env->startSection('keywords', $setting->keywords); ?>

<?php $__env->startSection('javascript'); ?>

<style>
    #owl-demo .item, #owl-demo-1 .item{
        background: #3fbf79;
        padding: 30px 0px;
        margin: 10px;
        color: #FFF;
        -webkit-border-radius: 3px;
        -moz-border-radius: 3px;
        border-radius: 3px;
        text-align: center;
        width: 190px;
    }
    .customNavigation{
        text-align: center;
    }
    .customNavigation a{
        -webkit-user-select: none;
        -khtml-user-select: none;
        -moz-user-select: none;
        -ms-user-select: none;
        user-select: none;
        -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
    }
</style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('home._slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="p-2 bg-ruam text-white row justify-content-md-center">
        <div class="col-md-auto">
            <img class="home-middle-logo" width="100px" src="<?php echo e(asset('assets')); ?>/images/website_logo.png" alt="logo" />
        </div>
        <div class="col col-lg-4">
            <h4>金属加工.comが選べる理由</h4>
        </div>
    </div>
    <div class="p-3 bg-orange text-white row justify-content-md-center">
        <div class="col col-md-auto row justify-content-start">
            <div class="col-md-auto"><h1 class="large-number">1</h1></div>
            <div class="col-md-auto row align-items-end">
                <div>
                    <h5>枚から加工OK!</h5>
                    <span>大量発注にも対応致します</span>
                </div>
            </div>
        </div>
        <div class="col col-md-auto row justify-content-start">
            <div class="col-md-auto"><h1 class="large-number">2</h1></div>
            <div class="col-md-auto row align-items-end">
                <div>
                    <h5>短納期で <br/>お届け致します!</h5>
                </div>
            </div>
        </div>
        <div class="col col-md-auto row justify-content-start">
            <div class="col-md-auto"><h1 class="large-number">3</h1></div>
            <div class="col-md-auto row align-items-end">
                <div>
                <h5>お求め安い価格で<br/>対応致します。</h5>
                </div>
            </div>
        </div>
        <div class="col col-md-auto row justify-content-start">
            <div class="col-md-auto"><h1 class="large-number">4</h1></div>
            <div class="col-md-auto row align-items-end">
                <div>
                    <h5>WEB上で<br/>簡単自動決済！</h5>
                </div>
            </div>
        </div>
    </div>
    <!-- Page Content -->
    <div class="container">
        <!-- About Section -->
        <div class="home-main">
            <div class="row">
                <div class="col-lg-3">
                    <div class="pt-3 pb-3">
                        <a href="" class="btn btn-danger btn-lg btn-block" id="btnCart">
                            <i class="fas fa-shopping-cart"></i> カートを見る
                        </a>
                    </div>
                    <div class="border bg-yellow-thin">
                        <div class="p-2 bg-secondary text-white text-center">
                            アカウント情報
                        </div>
                        <div class="text-center bg-white p-2 border-bottom">
                            <span>[お客様名]：　ゲスト　様</span>
                        </div>
                        <div class="row justify-content-center ">
                            <div class="col text-center p-2 border-right"><a href="mypage">ログイン</a></div>
                            <div class="col text-center p-2"><a href="member">新規会員登録</a></div>
                        </div>
                    </div>
                    <div class="mt-3 metal-list-box">
                        <div class="metal-list-box-header row justify-content-between pl-2 pt-2">
                            <div class="col-md-7 text-white">金属加工種類から 見積り作成</div>
                            <div class="col-md-auto"><img class="logo" width="85px" src="<?php echo e(asset('assets')); ?>/images/website_logo.png" alt="logo" /></div>
                        </div>
                        <div class="metal-list-box-body">
                            <div class="row justify-content-center">
                                <div class="col-lg-5">
                                    <a href="">
                                        <img src="https://www.itamage.com/archives/item/side_0-1.gif" alt="0-01" />
                                    </a>
                                </div>
                                <div class="col-lg-5">
                                    <a href="">
                                        <img src="https://www.itamage.com/archives/item/side_0-1.gif" alt="0-01" />
                                    </a>
                                </div>
                            </ul>
                            <ul class="clearfix">
                                <li><a href="https://www.itamage.com/bend/bend_draft.html?id=11"><img src="https://www.itamage.com/themes/itamage/common_img/side_bend_ita.gif" alt="金属板" width="105" height="60" /></a></li>
                                <li><a href="https://www.itamage.com/bend/bend_draft.html?id=14"><img src="https://www.itamage.com/themes/itamage/common_img/side_bend_pan.gif" alt="パンチング" width="105" height="60" /></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-lg-9">fsadf</div>
            </div>
            <!-- /.row -->
        </div>
    </div>

    <div class="blog-slide">
        <div class="container">
            <br>
            <h2>Announcements</h2>
            <div class="row">
                <div class="col-lg-12">
                    <div id="announcements" class="owl-carousel">
                        <?php $__currentLoopData = $announcement; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="post-slide">
                                <a style="text-decoration: none;" href="<?php echo e(route('content', ['id'=>$rs->id, 'slug'=>$rs->slug])); ?>">
                                    <div class="post-header">
                                        <h6 style="color: #161616" class="title">
                                            <?php echo e($rs->title); ?>

                                        </h6>
                                        <ul class="post-bar">
                                            <li ><img src="<?php echo e($rs->user->profile_photo_url); ?>" alt=""><span style="margin-left: 5px;"><?php echo e($rs->user->name); ?></span></li>
                                            <li><i class="fa fa-calendar"></i><?php echo e($rs->created_at->format('Y-m-d')); ?></li>
                                        </ul>
                                    </div>
                                    <div class="pic">
                                        <img src="<?php echo e(Storage::url($rs->image)); ?>" alt="">
                                    </div>
                                    <p class="post-description"><?php echo e($rs->description); ?></p>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <br>

    <div class="blog-slide">
        <div class="container">
            <br>
            <h2>News</h2>
            <div class="row">
                <div class="col-lg-12">
                    <div id="news" class="owl-carousel">
                        <?php $__currentLoopData = $news; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="post-slide">
                                <a style="text-decoration: none;" href="<?php echo e(route('content', ['id'=>$rs2->id, 'slug'=>$rs2->slug])); ?>">
                                    <div class="post-header">
                                        <h6 style="color: #161616" class="title">
                                            <?php echo e($rs2->title); ?>

                                        </h6>
                                        <ul class="post-bar">
                                            <li ><img src="<?php echo e($rs2->user->profile_photo_url); ?>" alt=""><span style="margin-left: 5px;"><?php echo e($rs2->user->name); ?></span></li>
                                            <li><i class="fa fa-calendar"></i><?php echo e($rs2->created_at->format('Y-m-d')); ?></li>
                                        </ul>
                                    </div>
                                    <div class="pic">
                                        <img src="<?php echo e(Storage::url($rs2->image)); ?>" alt="">
                                    </div>
                                    <p class="post-description"><?php echo e($rs2->description); ?></p>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script type="javascript">

    </script>
    <!-- /.container -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MetalPlate\Project\metalplate\resources\views/home/index.blade.php ENDPATH**/ ?>