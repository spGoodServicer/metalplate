<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content=" <?php echo $__env->yieldContent('description'); ?> ">
    <meta name="keywords" content=" <?php echo $__env->yieldContent('keywords'); ?> ">
    <meta name="author" content="Berke Kiran">
    <title> <?php echo $__env->yieldContent('title'); ?> </title>
    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('assets')); ?>/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Fontawesome CSS -->
    <link href="<?php echo e(asset('assets')); ?>/css/all.css" rel="stylesheet">
    <!-- Owl Carousel CSS -->
    <link href="<?php echo e(asset('assets')); ?>/css/owl.carousel.min.css" rel="stylesheet">
    <!-- Owl Carousel CSS -->
    <link href="<?php echo e(asset('assets')); ?>/css/jquery.fancybox.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="<?php echo e(asset('assets')); ?>/css/style.css" rel="stylesheet">

    <?php echo $__env->yieldContent('css'); ?>


</head>
<body>
<div class="wrapper-main">
    <?php echo $__env->make('home._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('home._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>

<!-- Bootstrap core JavaScript -->
<script src="<?php echo e(asset('assets')); ?>/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/vendor/bootstrap-wizard/jquery.bootstrap.wizard.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/imagesloaded.pkgd.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/isotope.pkgd.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/filter.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/jquery.appear.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/owl.carousel.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/jquery.fancybox.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/script.js"></script>
<?php echo $__env->yieldContent('javascript'); ?>
</body>
</html>
<?php /**PATH D:\MetalPlate\Project\metalplate\resources\views/layouts/home.blade.php ENDPATH**/ ?>