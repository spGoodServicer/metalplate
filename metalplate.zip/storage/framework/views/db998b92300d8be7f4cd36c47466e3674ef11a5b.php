<?php
    $parentMenus = \App\Http\Controllers\HomeController::menuList();
?>

<style>

    @media  only screen and (max-width: 960px) {
        .navbar-nav{
            flex-direction: column;
        }

        .container{
            width: 100%;
        }

        .navbar-expand-lg{
            -ms-flex-flow: row nowrap;
            flex-flow: row nowrap;
            -ms-flex-pack: start;
            justify-content: flex-start;
        }

        .menuctoggler{
            background-color: cornflowerblue;
        }

        .menuctoggler span{
            color:white;
        }

        .menuctoggler:hover{
            background-color: #FF0055;
        }

    }

    @media  only screen and (min-width: 960px) {
        .navbar-nav{
            flex-direction: row;
        }

        .container{
            width: 100%;
        }

        .navbar-expand-lg{
            -ms-flex-flow: row nowrap;
            flex-flow: row nowrap;
            -ms-flex-pack: start;
            justify-content: flex-start;
        }

        .menuctoggler{
            background-color: cornflowerblue;
        }

        .menuctoggler span{
            color:white;
        }

        .menuctoggler:hover{
            background-color: #FF0055;
        }

    }

</style>

<div class="pos-f-t">
    <div class="collapse" id="navbarToggleExternalContent">
        <div class="bg-dark p-4">
            <div class="container">
                <ul class="navbar-nav ml-auto">

                    <?php $__currentLoopData = $parentMenus->sortBy('id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if(count($rs->children->where('status','=','True'))==0): ?>
                            <li class="nav-item" style="margin-right: 10px;">
                                <a class="nav-link" href="<?php echo e(route('menucontent', ['id'=>$rs->id, 'slug'=>$rs->slug])); ?>"><div class="hover-item"><?php echo e($rs->title); ?></div></a>
                            </li>
                        <?php endif; ?>

                        <?php if(count($rs->children->where('status','=','True'))!=0): ?>
                            <li class="nav-item dropdown" style="margin-right: 10px;">
                                <a class="nav-link" id="navbarDropdownBlog" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="color: white;"> <div class="hover-item"><?php echo e($rs->title); ?> <i style="margin-left: 5px;" class="fas fa-sort-down"></i></div>
                                    <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownBlog">
                                        <?php if(count($rs->children->where('status','=','True'))): ?>
                                            <?php $__currentLoopData = $rs->children->sortBy('id'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submenu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <a class="dropdown-item" href="<?php echo e(route('menucontent', ['id'=>$submenu->id, 'slug'=>$submenu->slug])); ?>"><div class="hover-item-dark"><?php echo e($submenu->title); ?></div></a>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php endif; ?>
                                    </div>
                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </ul>
            </div>

        </div>
    </div>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <button style="display: flex; margin-left: 70%; width: 150px" class="menuctoggler navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarToggleExternalContent" aria-controls="navbarToggleExternalContent" aria-expanded="false" aria-label="Toggle navigation">
            <span style="margin-left: auto; margin-right: auto;">
                <span style="margin-right: 5px;" class="navbar-toggler-icon"></span> Menu
            </span>
        </button>
    </nav>

</div>
<?php /**PATH D:\MetalPlate\Project\metalplate\resources\views/home/_menu.blade.php ENDPATH**/ ?>