<?php $__env->startSection('title', '切り出し'); ?>

<?php $__env->startSection('content'); ?>
    <!-- MAIN service-->
    <div class="main-content">
        <div class="section__content section__content--p30">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-5">
                        <div class="card">
                            <div class="card-header">材料</div>
                            <div class="card-body">
                                <table
                                    data-toggle="table"
                                    data-url="<?php echo e(route('admin_cut_get_material')); ?>"
                                    data-pagination="true"
                                    data-search="true">
                                    <thead>
                                      <tr>
                                        <th>Item ID</th>
                                        <th>Item Name</th>
                                        <th>Item Price</th>
                                      </tr>
                                    </thead>
                                    <tbody>
                                      <tr>
                                        <td>1</td>
                                        <td>Item 1</td>
                                        <td>$1</td>
                                      </tr>
                                      <tr>
                                        <td>2</td>
                                        <td>Item 2</td>
                                        <td>$2</td>
                                      </tr>
                                    </tbody>
                                  </table>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-5">
                        <!-- DATA TABLE -->
                        <h3 class="title-5 m-b-35">切り出し</h3>
                        <div class="table-data__tool">
                            <div class="table-data__tool-left">
                                <button class="au-btn au-btn-icon au-btn--green au-btn--small">
                                    <i class="zmdi zmdi-plus"></i><a style="color:white;" href="<?php echo e(route('admin_faq_add')); ?>">Add Faq</a></button>
                            </div>
                        </div>
                        <div class="table-responsive table-responsive-data2" >
                            <table class="table table-data2" data-toggle="table">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>加工一覧</th>
                                        <th>材料</th>
                                        <th>比重</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>Item 1</td>
                                        <td>Item 1</td>
                                        <td>$1</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <!-- END DATA TABLE -->
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="copyright">
                            <p>© 2022 moon.rider.dev</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- END MAIN service-->
    <!-- END PAGE CONTAINER-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MetalPlate\Project\metalplate\resources\views/admin/cut.blade.php ENDPATH**/ ?>