<a class="dropdown-item" href="<?php echo e(route('user_profile')); ?>"><i style="margin-right: 20px;" class="fas fa-user-cog"></i><b>My Profile</b></a>
<?php
    use Illuminate\Support\Facades\Auth;
    $userRoles = Auth::user()->roles->pluck('name');
?>
<?php if(auth()->guard()->check()): ?>
    <?php if($userRoles->contains('admin')): ?>
        <a class="dropdown-item" href="<?php echo e(route('admin_home')); ?>"><i style="margin-right: 20px;" class="fas fa-shield-alt"></i><b>Admin Panel</b></a>
    <?php endif; ?>
<?php endif; ?>
<a class="dropdown-item" href="<?php echo e(route('user_content')); ?>"><i style="margin-right: 20px;" class="fas fa-clone"></i><b>My Contents</b></a>
<a class="dropdown-item" href="<?php echo e(route('user_comment')); ?>"><i style="margin-right: 20px;" class="fas fa-comments"></i><b>My Comments</b></a>
<form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button style="cursor:pointer; outline:none;" class="dropdown-item" href="" type="submit"><i style="margin-right: 20px;" class="fas fa-user-times"></i><b>Logout</b></button></form>
<?php /**PATH D:\MetalPlate\Project\metalplate\resources\views/user/usermenu.blade.php ENDPATH**/ ?>