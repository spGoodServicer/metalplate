<?php $__env->startSection('title', 'About Us'); ?>
<?php $__env->startSection('description', $setting->description); ?>
<?php $__env->startSection('keywords', $setting->keywords); ?>

<?php $__env->startSection('content'); ?>

    <!-- full Title -->
    <div class="full-title">
        <div class="container">
            <!-- Page Heading/Breadcrumbs -->
            <h1 class="mt-4 mb-3"> About Us </h1>
            <div class="breadcrumb-main">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(route('home')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item active"> About Us </li>
                </ol>
            </div>
        </div>
    </div>

    <div class="blog-main">
        <div class="container">
            <div class="row">
                <!-- Post Content Column -->
                <div class="col-lg-16">
                    <?php echo $setting->aboutus; ?>

                </div>
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container -->
    </div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\MetalPlate\Project\metalplate\resources\views/home/aboutus.blade.php ENDPATH**/ ?>