@extends('layouts.admin')

@section('title', 'Admin Panel')

@section('content')
    @include('admin._content')
@endsection
