@extends('layouts.admin')

@section('title', 'Admin Panel Blank Page')

@section('content')

@endsection
